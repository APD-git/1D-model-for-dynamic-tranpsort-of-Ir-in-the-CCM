function [boolCDon, boolRedepOn, boolDepCCL] = getBools(t, p2)
% get booleans for different phenomena during either on- or idle phases
    
    boolCDon    = getBoolCDon(p2.Del_t, t, p2);             % ask whether CD is on or off           
    boolRedepOn	= getBoolRedepOn(p2.Del_t, t, p2);          % redeposition in ACL active or not
    boolDepCCL  = boolCDon;                                 % EC deposition -> on when CD is on

end

