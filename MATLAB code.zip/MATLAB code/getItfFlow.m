function [Fl_memMigIr, Fl_memDiffIr, migVel] = getItfFlx(t, p, p2, n_Ir, c_Ir_m, idx_itf, cd_O2)
% get interface fluxes
% idea: Separate this calculation since these fluxes are not necessary for 
% simulation. Just for plotting.
% idx_itf: Index of the interface which shall be calculated

    c_Ir_ACL 	= n_Ir/p.V_ACL_io;                  % [mol/m3] Dirichlet-BC   
%     cd_O2     	= p.cd*getBoolCDon(p2.Del_t, t, p2);       	% [A/m2]
    sig_O2      = p.A*cd_O2/(4*p.F);                % [mol/s]


    
%     n_H        	= p.n_H_ACL_0 - p.z_Ir*n_Ir;                    % [mol] amount of H+
    
%     Fl_PTL_Ir 	= sig_O2/p.S_num_PTL;                           % [mol/s] S_num = O2/Ir // Flow to the PTL side
  
    gradPhi   	= - cd_O2/p.kappa;                              % [V/m]
    
    mig_mem   	= -1*p.D_Ir*p.z_Ir*p.F*gradPhi/(p.R*p.T);       % [m/s] migration velocity
%     mig_mem
    migVel    	= mig_mem;                                      % [m/s] migration velocity
%     conVel  	= p.voFl_H2Odrag*p.boolConv;                    % [m/s] convection veleocity

    
    % taking point 3 and 2 (point 1 is c_Ir_ACL) is numerically more stable than 2 and 1
    Fl_memDiffIr   = -p.A*p.D_Ir*(  c_Ir_m(idx_itf+1,1) - c_Ir_m(idx_itf,1)  )/p.Del_x_m;      	% [mol/s] diffusion at ACL/mem interface

%     Fl_memMigIr    = migVel*c_Ir_ACL;                             % [mol/s] migration at ACL/mem interface
%     Fl_memConIr    = conVel*c_Ir_ACL;                             % [mol/s] convection and ACL/mem interface
    Fl_memMigIr    = p.A*migVel*c_Ir_m(idx_itf,1);                	% [mol/s] migration at ACL/mem interface (m*mol*m2/(s*m3)
%     Fl_memConIr    = p.A*conVel*c_Ir_m(idx_itf,1);               	% [mol/s] convection and ACL/mem interface

end

