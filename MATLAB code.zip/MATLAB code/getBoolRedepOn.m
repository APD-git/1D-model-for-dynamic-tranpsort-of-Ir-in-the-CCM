function [bool] = getBoolRedepOn(Del_t, t, p2)
% Function determines whether redeposition in ACL is active or not
    
        % dynamic profiles 0V and 1.3V
        numHalfCycCompl = floor(t/Del_t);  % round down
        
        if mod(numHalfCycCompl,2)==0    % even number (=start)
            % off phase
            bool = 1;       % Attention: Starting with cd non-zero results in numerical difficulties!
                           
        else
            % on-phase
            bool = 0;       % redeposition in ACL off during on-phase

        end

    
end

