

%% go through all notes and display
 
fields = fieldnames(note);

for i = 1:numel(fields)
  disp(['*** ', note.(fields{i}), ' ***']);
end