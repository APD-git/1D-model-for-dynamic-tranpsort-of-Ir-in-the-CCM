function [ddct, Fl_memDiffIr, Fl_memMigIr, sigDi, sigRedep, Fl_memCCL, RdepCCL, boolRdep] ...
    = modelEqns(x, p, p2, t)
% constitutive model equations
    
    % ACL domain
    nIrACL    	= x(1,1);                           % [mol] amount of Ir ions in ACL
    nIrCCL      = x(2,1);                           % [mol]
    nDepCCL     = x(3,1);                           % [mol]
    nDepACL     = x(4,1);                           % [mol]
    c_Ir_ACL 	= nIrACL/p.V_ACL_io;              	% [mol/m3] Dirichlet-BC   
    cIrCCL      = nIrCCL/p.V_CCL;                   % [mol/m3]
    
    % [-] get booleans (1 = phenomenon active)
    [boolCDon, boolRedepOn, boolDepCCL] = getBools(t, p2);
    
  	cd_O2  	    = p.cd*boolCDon;                % [A/m2]
    sig_O2      = p.A*cd_O2/(4*p.F);            % [mol/s]
    sigDi       = sig_O2/p.S_num;               % [mol/s]
    
    sigRedep    = p.kRedep*p.V_ACL_io*c_Ir_ACL*boolRedepOn;             % [mol/s] redeposition in ACL
    RdepCCL   	= cIrCCL*p.V_CCL*p.kDepCCL*boolDepCCL;    	            % [mol/s] deposition in CCL
    
    % membrane domain
    c_Ir_m(1,1)                 = c_Ir_ACL;             	                        % [mol/m3] Dirichlet-BC at x=0
    c_Ir_m(2:p.numOfEl_m+1,1)   = x(p.firIdxMem:p.numOfEl_m+(p.firIdxMem-1),1);     % [mol/m3] obtain current concentration values inside membrane domain
    c_Ir_m(p.numOfEl_m+2,1)     = cIrCCL;                 	                        % [mol/m3] Dirichlet-BC at x=d_mem
    
    idx_itf = 2;    % index for which the interface fluxes shall be calculated
    [Fl_memMigIr, Fl_memDiffIr, migVel] = getItfFlow(t, p, p2, nIrACL, c_Ir_m, idx_itf, cd_O2);     % [mol/s]
    
    % setup transport matrix
    p.A_m   = p.D_Ir/(p.Del_x_m^2);
    p.B_m   = -2*p.D_Ir/(p.Del_x_m^2) - migVel/p.Del_x_m;
    p.C_m   = p.D_Ir/(p.Del_x_m^2) + migVel/p.Del_x_m;
    for i=1:p.numOfEl_m
       p.M_ext(i,i)     = p.C_m;
       p.M_ext(i,i+1)   = p.B_m;
       p.M_ext(i,i+2)   = p.A_m;
    end
    
    % calculate the dynamic change of Ir distrution in mem
    ddct            = p.M_ext*c_Ir_m;                                           % [mol/(m3*s)] column vector
    
    % Flow between membrane and CCL
    Fl_memCCL = p.A*(   -p.D_Ir*(  cIrCCL - c_Ir_m(p.numOfEl_m+1)  )/p.Del_x_m  +  migVel*c_Ir_m(p.numOfEl_m+1)   );
end

