fig.x0 = 5; fig.y0 = 35; fig.width = 830; fig.height = 460;
gruen   = '#3adf1d';
niceRed = '#d30000';


%%

t_tot_frac  = 0.02;              % fraction of total time to be plotted (beginning or end)
showStart   = 1;
showEnd     = 0;


MSfig1 = figure('Name', 'Figures for publication ("showMSfigs.m")');
        set(gcf,'color','w');
        set(MSfig1, 'units', 'points', 'position', [fig.x0, fig.y0, fig.width, fig.height]);
        
        lenx      = 5;
        pink         = [1, 0, 0];
%         pink        = [255, 192, 203]/255;
        red        = [0, 0, 255]/255;
        colors_p    = [linspace(red(1),pink(1),lenx)', linspace(red(2),pink(2),lenx)', linspace(red(3),pink(3),lenx)'];

        set(gcf,'color','w');
            
        % get indices for plotting
        idx1 = round(p2.num_t_points*p2.tRelMS1);
        idx2 = round(p2.num_t_points*p2.tRelMS2);
        idx3 = round(p2.num_t_points*p2.tRelMS3);
        idx4 = round(p2.num_t_points*p2.tRelMS4);
        idx5 = round(p2.num_t_points*p2.tRelMS5);
        
        
        if showEnd==1
            t_tot_frac = t_tot_frac;  % relative section
            idx1 = round(p2.num_t_points*(1-t_tot_frac)) + round(p2.num_t_points*t_tot_frac*p2.tRelMS1);
            idx2 = round(p2.num_t_points*(1-t_tot_frac)) + round(p2.num_t_points*t_tot_frac*p2.tRelMS2);
            idx3 = round(p2.num_t_points*(1-t_tot_frac)) + round(p2.num_t_points*t_tot_frac*p2.tRelMS3);
            idx4 = round(p2.num_t_points*(1-t_tot_frac)) + round(p2.num_t_points*t_tot_frac*p2.tRelMS4);
            idx5 = round(p2.num_t_points*(1-t_tot_frac)) + round(p2.num_t_points*t_tot_frac*p2.tRelMS5);      
        end    
        
        
        if showStart==1
%             t_tot_frac = t_tot_frac;  % relative section
            idx1 = round(p2.num_t_points*t_tot_frac)*0 + round(p2.num_t_points*t_tot_frac*p2.tRelMS1);
            idx2 = round(p2.num_t_points*t_tot_frac)*0 + round(p2.num_t_points*t_tot_frac*p2.tRelMS2);
            idx3 = round(p2.num_t_points*t_tot_frac)*0 + round(p2.num_t_points*t_tot_frac*p2.tRelMS3);
            idx4 = round(p2.num_t_points*t_tot_frac)*0 + round(p2.num_t_points*t_tot_frac*p2.tRelMS4);
            idx5 = round(p2.num_t_points*t_tot_frac)*0 + round(p2.num_t_points*t_tot_frac*p2.tRelMS5);      
        end    
        
        subplot(2,3,1)
            plot(grid*10^6, s.c_Ir_mem_nSI(idx1,1:p.numOfEl_m)', '--.', 'LineWidth', 1.5, 'Color',colors_p(1,:));   % [m -> um]
            hold on;
            plot(grid*10^6, s.c_Ir_mem_nSI(idx2, 1:p.numOfEl_m)', '-', 'LineWidth', 1.5, 'Color', colors_p(2,:));
            plot(grid*10^6, s.c_Ir_mem_nSI(idx3, 1:p.numOfEl_m)', '-.', 'LineWidth', 1.5, 'Color', colors_p(3,:));
            plot(grid*10^6, s.c_Ir_mem_nSI(idx4, 1:p.numOfEl_m)', ':', 'LineWidth', 1.5, 'Color', colors_p(4,:));
            plot(grid*10^6, s.c_Ir_mem_nSI(idx5, 1:p.numOfEl_m)', '--', 'LineWidth', 1.5, 'Color', colors_p(5,:));
            
            plot(0, s.cIrACL_nSI(idx1), 'o', 'Color', colors_p(1,:), 'MarkerSize', 4, 'LineWidth', 1);
            plot(0, s.cIrACL_nSI(idx2), 'o', 'Color', colors_p(2,:), 'MarkerSize', 4, 'LineWidth', 1);
            plot(0, s.cIrACL_nSI(idx3), 'o', 'Color', colors_p(3,:), 'MarkerSize', 4, 'LineWidth', 1);
            plot(0, s.cIrACL_nSI(idx4), 'o', 'Color', colors_p(4,:), 'MarkerSize', 4, 'LineWidth', 1);
            plot(0, s.cIrACL_nSI(idx5), 'o', 'Color', colors_p(5,:), 'MarkerSize', 4, 'LineWidth', 1);
            plot(grid(length(grid))*10^6, s.cIrCCL(idx1)/1000, 'o', 'Color', colors_p(1,:), 'MarkerSize', 4, 'LineWidth', 1);
            plot(grid(length(grid))*10^6, s.cIrCCL(idx2)/1000, 'o', 'Color', colors_p(2,:), 'MarkerSize', 4, 'LineWidth', 1);
            plot(grid(length(grid))*10^6, s.cIrCCL(idx3)/1000, 'o', 'Color', colors_p(3,:), 'MarkerSize', 4, 'LineWidth', 1);
            plot(grid(length(grid))*10^6, s.cIrCCL(idx4)/1000, 'o', 'Color', colors_p(4,:), 'MarkerSize', 4, 'LineWidth', 1);
            plot(grid(length(grid))*10^6, s.cIrCCL(idx5)/1000, 'o', 'Color', colors_p(5,:), 'MarkerSize', 4, 'LineWidth', 1);

            xlim([0, 100]);

            xlabel('Membrane position x [µm]');
            ylabel('Ir^{n+} conc. [mol/L]', 'Position', get(gca,'ylabel').Position - [5 0 0]);

            box on; ax = gca; ax.LineWidth = 1;


            h = legend([sprintf('%.1f min', p.t_points(idx1)/60)], ...          % [s -> min]
           [sprintf('%.1f min', p.t_points(idx2)/60)], ...                      
           [sprintf('%.1f min', p.t_points(idx3)/60)], ...
           [sprintf('%.1f min', p.t_points(idx4)/60)], ...
           [sprintf('%.1f min', p.t_points(idx5)/60)], ...
           'Position',[0.15359 0.69082 0.0700 0.136104], 'LineWidth', 0.5);

            h.ItemTokenSize = [15 15];

            ytickformat('%.1f');
            
            xticks([0,25,50,75,100]);
            pbaspect([1 1 1]);

