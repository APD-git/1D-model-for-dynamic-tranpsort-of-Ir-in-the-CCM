%% get parameters 
   
    
%% simulation parameter groups ("p2")

    % Sometimes, uneven numbers are better numerically
%     p2.tSpanMin  	= 1*30;
%     p2.tSpanMin  	= 3*59;           % [s]
    p2.tSpanMin  	= 30*59;        % [s] 30*59 used for publication: Fast vs slow kDepCCL
%     p2.tSpanMin     = 50*59;        % [s] 
%     p2.tSpanMin     = 52*59;        % [s] used for frequency dependence analysis

%     p2.Del_t        = 1*60;         % [s] hold duration at constant current (= half of cycle duration).
%     p2.Del_t        = 2*60;         % [s] hold duration at constant current (= half of cycle duration).
%     p2.Del_t        = 3.5*60;       % [s] hold duration at constant current (= half of cycle duration).
%     p2.Del_t        = 5*60;         % [s] hold duration at constant current (= half of cycle duration).
%     p2.Del_t        = 12.5/2*60;     	% [s] hold duration at constant current (= half of cycle duration).
%     p2.Del_t        = 7.5*60;        % [s] hold duration at constant current (= half of cycle duration).
    p2.Del_t        = 10*60;        % [s] hold duration at constant current (= half of cycle duration).
% 	  p2.Del_t        = 12.5*60;     	% [s] hold duration at constant current (= half of cycle duration).
%     p2.Del_t        = 15*60;          % [s] hold duration at constant current (= half of cycle duration).
%     p2.Del_t        = 17.5*60;        % [s] hold duration at constant current (= half of cycle duration).
%     p2.Del_t        = 20*60;          % [s] hold duration at constant current (= half of cycle duration).

    % Choosing the right one was sometimes imperative to get numerical proper simulation (see n_CCL plot, there should be no kinks)
%     p2.num_t_points	= 20*2000;                      % [-] 
    p2.num_t_points	= 2*2000;                           % [-] used for some cases - see excel
%     p2.num_t_points	= 100*2000;                    % [-] Used for some cases - see excel
%     p2.num_t_points	= 150*2000;                    % [-]

    
    
    p.S_num         = 4*10^7;    	% [-] stability-number
    
%     p.kDepCCL       = 2e-2;         % [m3/s] slow CCL deposition case
    p.kDepCCL       = 1e+2;         % [m3/s] fast CCL deposition case

    p.kRedep        = 75.91;            % redeposition constant at ACL. Fast: 75.91
    



%% simulation parameters
    
%     p2.num_t_points  = 300;                    % [-]
    
    p.t_span        = p2.tSpanMin*60;                 % [s]

    p.t_points      = linspace(0, p.t_span, p2.num_t_points);   % [s]
    p.del_t         = p.t_span/(p2.num_t_points-1);


%% membrane domain

    p.d_mem     = 100*10^-6;                    % [m] 100 um

%     p.numOfEl_m     = 20;                                   % 
%     p.numOfEl_m     = 30;                                   %  30
    p.numOfEl_m     = 40;                                       %  40 (used for simulations - see excel)

    grid            = linspace(0, p.d_mem, p.numOfEl_m);        % [m] grid for finite volume method
    p.Del_x_m       = p.d_mem/p.numOfEl_m;                      % distance between two grid points


%% Operation and design conditions
    
    p.cd_nSI    = 1;                            % [A/cm2]
    p.cd        = p.cd_nSI*10^4;                % [A/m2]
    
    p.T_nSI     = 60;                           % [°C]
    p.T         = p.T_nSI+273.15;               % [K]

    p.V_ACL_io  = 3.9520e-10;                   % [m3] volume of ACL ionomer phase
    p.V_CCL     = 5.0e-10;                      % [m3]


%% material properties

    p.fracCat   = 0.76;                         % fraction of Ir dissolved as cations 

%     p.D_Ir          = 6.5*10^-12;                       % [m2/s] Al(3+)Prakash, SenGupta 2005, Ehelebe Pt in Nafion 2*10^-11
    p.D_Ir          = 2*10^-11;                         % [m2/s] Suresh, Goswami 2004; Nafion117; 300.15K; Cs+: 1.94*10^-11; Cu2+: 2.9*10^-11; 4.5*10^-12
  	
% membrane conductivity from Ito, Takenata 2011
    p.E_k           = 7829;                             % [J/mol]
    p.kappa0        = 2.29*100;                         % [S/m]
    p.kappa         = p.kappa0*exp(-p.E_k/(p.R*p.T));   % [S/m]
    
% charge number for migration
    p.z_Ir          = 3;                % [-]                      
    p.z_H           = 1;                % [-]
    
    
%% Ir concentration of Knöppel used for redeposition test
    
    kn.c_Kn_nSI1         = 10;                          % [ppb]
    kn.c_Kn_nSI2         = kn.c_Kn_nSI1*10^-9;          % [g_Ir/g_tot = g/mL]
    kn.c_Kn_nSI3         = kn.c_Kn_nSI2*0.001*1000;     % [kg/L]
    kn.c_Kn_nSI4         = kn.c_Kn_nSI3*p.M_Ir;         % [mol/L]
    
% calculation water drag
    p.dragFac           = 2;                            % [-] drag factor
    p.moFl_H            = p.cd/(1*p.F);                 % [mol/(m2*s)]
    p.moFl_H2Odrag      = p.moFl_H*p.dragFac;           % [mol/(m2*s)]
    p.maFl_H2Odrag      = p.moFl_H2Odrag*p.M_H2O;       % [kg/(m2*s)]
    p.voFl_H2Odrag      = p.maFl_H2Odrag/p.rho_H2O;     % [m3/(m2*s)] 
    

%% determine t points for plotting

% setting for slow vs fast deposition reaction in CCL (slow)
%     p2.tRelMS1        = 1/8;
%     p2.tRelMS2        = 1/3;
%     p2.tRelMS3        = 1/2.6;
%     p2.tRelMS4        = 1/1.9;
%     p2.tRelMS5        = 1/1.5; 

% setting for slow vs fast deposition reaction in CCL (fast)
    p2.tRelMS1        = 1/8;
    p2.tRelMS2        = 1/3.1;
    p2.tRelMS3        = 1/2.99;
    p2.tRelMS4        = 1/1.9;
    p2.tRelMS5        = 1/1.6; 
