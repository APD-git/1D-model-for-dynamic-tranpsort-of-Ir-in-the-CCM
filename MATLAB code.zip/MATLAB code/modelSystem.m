function [dxdt] = modelSystem(t, x, p, p2)
% returns column vector with rates of change for the states

    [ddct, Fl_memDiff_Ir, Fl_memMig_Ir, sigDi, sigRedep, ...    %
        Fl_memCCL, RdepCCL] = modelEqns(x, p, p2, t);           % model equations to calculate rates
    

    % mole balances
    dxdt(1,1)    	= p.fracCat*sigDi - Fl_memDiff_Ir ...       % 
        - Fl_memMig_Ir - sigRedep;                              % [mol/s] amount of Ir ions in ACL

    dxdt(2,1)       = Fl_memCCL - RdepCCL ;                     % [mol/s] amount of Ir ions in CCL
    dxdt(3,1)       = RdepCCL;                                  % [mol/s] change of amount of Ir depos. in CCL
    dxdt(4,1)       = sigRedep;                                 % [mol/s]
    dxdt(5,1)       = p.fracCat*sigDi;                          % [mol/s]
    
    % rate of change in membrane domain
    dxdt(p.firIdxMem:p.numOfEl_m+(p.firIdxMem-1),1) = ddct;     % [mol/(m3*s)]
end

