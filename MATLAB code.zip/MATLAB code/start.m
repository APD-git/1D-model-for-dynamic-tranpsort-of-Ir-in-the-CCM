%%     Dynamic 1D-model of Ir transport in the CCM          %
%       Author: An Phuc Dam                                 % 
%       Email: dam@mpi-magdeburg.mpg.de                     %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    clear; clc; close all;
    
    tic; toc;
    getNatureConstants;
    note.init       = 'notifications active';         	% initialize notes
    p.A_nSI         = 5;                                % [cm2]
    p.A             = p.A_nSI*10^-4;                 	% [m2]
    

%% get parameters

    getParams;

    
%% set initial conditions of dynamic simulation

    X0(1)             	= 0;                % initial amount of Ir ions in ACL
    X0(2)             	= 0;                % initial Ir ions in CCL
    X0(3)              	= 0;                % initial deposited Ir in CCL
    X0(4)               = 1e-25;          	% amount of Ir redeposited in ACL
    X0(5)               = 0;                % amount dissolved from ACL ('brutto');   
    p.firIdxMem      	= 6;                % first index of membrane domain

    X0(p.firIdxMem:p.numOfEl_m+(p.firIdxMem-1))	= zeros(1,p.numOfEl_m);     % along the membrane

    
%% perform simulation

    opts = odeset('Stats','off');
%     opts = odeset('Stats','off', 'RelTol', 1E-6);
%     opts = odeset('Stats','off', 'NormControl','on');

    warning('off', 'MATLAB:rankDeficientMatrix');
    warning('off', 'MATLAB:nearlySingularMatrix');
    conductSim = 1;
    if conductSim ==1
%     [s.t, s.x_sol]   = ode15s(@(t,x) modelSystem(t, x, p, p2), p.t_points, X0); 
%     [s.t, s.x_sol]   = ode15i(@(t,x) modelSystem(t, x, p, p2), p.t_points, X0); 
%     [s.t, s.x_sol]   = ode23(@(t,x) modelSystem(t, x, p, p2), p.t_points, X0);
    [s.t, s.x_sol]   = ode23s(@(t,x) modelSystem(t, x, p, p2), p.t_points, X0);             % usually used
%     [s.t, s.x_sol]   = ode23t(@(t,x) modelSystem(t, x, p, p2), p.t_points, X0); 
%     [s.t, s.x_sol]   = ode23tb(@(t,x) modelSystem(t, x, p, p2), p.t_points, X0); 
%     [s.t, s.x_sol]   = ode45(@(t,x) modelSystem(t, x, p, p2), p.t_points, X0);
    
    
    disp('*** ODE solved ***');
    
    else
        load simData2;
        disp('*** simulation data loaded ***');
    end
    
%% after simulation calculations

    s.n_Ir        	= s.x_sol(:,1);                         % [mol]
    s.c_Ir        	= s.n_Ir/(p.V_ACL_io);                  % [mol/m3] accumulation assumed inside ionomer phase
    s.cIrACL_nSI    = s.c_Ir/1000;                          % [mol/L]
    M_Ir_nSI        = 192;                                  % [g/mol]
    s.cIrACL_nSI2 	= (s.cIrACL_nSI*M_Ir_nSI/1000)*10^6; 	% [ppm]
    
    s.nIrCCL     	= s.x_sol(:,2);                         % [mol] Amount of Ir ions in CCL
    s.cIrCCL      	= s.nIrCCL/p.V_CCL;                     % [mol/m3]
    
    s.nDepCCL     	    = s.x_sol(:,3);                     % [mol] Amount of Ir deposited in CCL
    s.mDepCCLperA  	    = s.nDepCCL*p.M_Ir/p.A;             % [kg/m2]
    s.mDepCCLperA_nSI	= s.mDepCCLperA*10^6*1000/10000;   	% [ug/cm2]
    
    s.nDepACL           = s.x_sol(:,4);                  	% [mol] Amount of Ir deposited in ACL
    s.mDepACLperA       = s.nDepACL*p.M_Ir/p.A;            	% [kg/m2]
    s.mDepACLperA_nSI	= s.mDepACLperA*10^6*1000/10000;	% [ug/cm2]
    
    s.nDiss             = s.x_sol(:,5);                 	% [mol] Amount of Ir deposited in ACL
    s.mDissPerA         = s.nDiss*p.M_Ir/p.A;             	% [kg/m2]
    s.mDissPerA_nSI     = s.mDissPerA*10^6*1000/10000;     	% [ug/cm2]
    
    s.c_Ir_mem          = s.x_sol(:, p.firIdxMem:p.numOfEl_m+(p.firIdxMem-1));   	% [mol/m3]
    s.c_Ir_mem_nSI      = s.c_Ir_mem/1000;                                        % [mol/L]
    
    
    % initialize for better computation
    s.Fl_mem_Ir_EN    = zeros(1, length(p2.num_t_points));
    s.n_H             = zeros(1, length(p2.num_t_points));
    s.Fl_PTL_Ir       = zeros(1, length(p2.num_t_points));
    s.Fl_memDiff_Ir   = zeros(1, length(p2.num_t_points));

    s.Fl_memMig_Ir    = zeros(1, length(p2.num_t_points));
    
    s.nCCLDepCalc2    = zeros(p2.num_t_points,1);         % [mol] initialize amount of Ir deposited in CCL
    s.nOut            = zeros(p2.num_t_points,1);         % [mol] initialize amount of Ir which left the ACL
  
    
    disp('*** Start for loop ***');
    for i=1:p2.num_t_points
        [s.ddtc(:,i), s.Fl_memDiff_Ir(i,1), s.Fl_memMig_Ir(i,1), s.sigDi(i,1), ...
            s.sigRedep(i,1), s.Fl_memCCL(i,1), s.RdepCCL(i,1)] ...
            = modelEqns(s.x_sol(i,:)', p, p2, s.t(i,1));
        
        s.FlOutTot(i,1) = s.Fl_memMig_Ir(i,1) + s.Fl_memDiff_Ir(i,1);   	% [mol/s] Total flow ACL/mem interface
        
        [s.boolCDon(i,1), s.boolRedepOn(i,1), s.boolDepCCL(i,1)] = getBools(s.t(i,1), p2);
        s.cd(i,1) = p.cd*s.boolCDon(i,1);
        
        idxMemCCL = p.numOfEl_m - 1;
        [s.FlMemCCLmig(i,1), s.FlMemCCLdiff(i,1), s.migVel(i,1)] ...
            = getItfFlow(s.t(i,1), p, p2, s.n_Ir(i,1), s.c_Ir_mem(i,:)', idxMemCCL, s.cd(i,1));
        
        s.FlMemCCLtot(i,1) = s.FlMemCCLmig(i,1) + s.FlMemCCLdiff(i,1);

        
    end
    disp('*** Post-calculations completed ***');

%%
    s.n_mem = zeros(p2.num_t_points, 1);          % [mol] initialize
    for j=1:p2.num_t_points                     % j: time; i: position
        for i=1:size(s.c_Ir_mem, 2)
           s.n_mem(j,1) = s.n_mem(j,1) + p.Del_x_m*p.A*s.c_Ir_mem(j,i); 
        end
    end
    
    s.memPlusCCL            = s.nDepCCL + s.n_mem;                  % [mol]
    
    s.mMemPlusCCLperA       = s.memPlusCCL*p.M_Ir/p.A;       	    % [kg/m2]
    s.mMemPlusCCLperA_nSI	= s.mMemPlusCCLperA*10^6*1000/10000;   	% [ug/cm2]
    
%%

    s.c_H_nSI         = s.n_H/(p.V_ACL_io*1000);            % [mol/L] attention
    s.fl_mem_Ir_EN    = s.Fl_mem_Ir_EN/p.A;                 % [mol/(m2*s)]
    
    s.fl_memDiff_Ir   = s.Fl_memDiff_Ir/p.A;                % [mol/(s*m2)]
    s.fl_memMig_Ir    = s.Fl_memMig_Ir/p.A;                 % [mol/(s*m2)]
    
    s.fl_memTot_Ir	= s.fl_memDiff_Ir + s.fl_memMig_Ir;  	% [mol/(s*m2)]
    s.Fl_memTot_Ir	= s.fl_memTot_Ir*p.A;                   % [mol/s]     
    
    
    s.mDepCCLperA        = s.nDepCCL*p.M_Ir/p.A;             	% [kg/m2]
    s.mDepCCLperA_nSI    = s.mDepCCLperA*10^6*1000/10000;   	% [ug/cm2]
    
    
%% display notes

    dispNotes;
    
    disp('***');
    disp(['Simulated hold time is: ', num2str(p2.Del_t/60), ' min']);
    toc;


%% Plotting

    showMSfigs;
    