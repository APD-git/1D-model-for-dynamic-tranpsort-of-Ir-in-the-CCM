function [bool] = getBoolCDon(Del_t, t, p2)
% Function defines on- and idle phases
% Gives out 1 when current density (CD) is on
    
    numHalfCycCompl = floor(t/Del_t);  % round down
    if mod(numHalfCycCompl,2)==0    % even number (=start)
        bool = 0;                 % Attention: Starting with cd non-zero results in numerical difficulties!
    else
        bool = 1;
    end

    
end

